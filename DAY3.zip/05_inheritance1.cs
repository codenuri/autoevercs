﻿// inheritance (상속 )

class Professor 
{
    private string name;
    private int age;
    private string major;
}
class Student 
{
    private string name;
    private int age;
    private string id;
} 

class Program
{
    public static void Main()
    {
        Student s = new Student();

    }
}
