﻿// this 활용
class Point
{
    private int x = 0;
    private int y = 0;

    public void Set(int x, int y)
    {
        x = x;
        y = y;
    }
    public Point Foo()
    {
        return this;
    }
}

class Program
{
    public static void Main()
    {
        Point p = new Point();
        p.Set(1, 2);

        p.Foo();
    }
}
