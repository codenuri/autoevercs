﻿class Animal
{
    public int age = 0;
}

class Dog : Animal
{
    public int color = 0;
}

class Cat : Animal
{
    public int speed = 0;
}

class Program
{
    public static void Main()
    {
        Dog r1 = new Dog(); // ?

        int r2 = new Dog(); // ?

        Animal r3 = new Dog(); // ?

    }
}