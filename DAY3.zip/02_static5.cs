﻿class Example
{
    private int data1 = 0;
    private static int data2 = 0;

    // 아래 코드에서 에러를 모두 고르세요
    public void M1()
    {
        data1 = 0; // ?
        data2 = 0; // ? 
    }
    public static void M2()
    {
        data1 = 0; // ?
        data2 = 0; // ?

    }
}
class Program
{
    public static Main()
    {
        Example.M2(); // 객체 없이 호출. 
    }
}