using static System.Console;

delegate void MyFunc(int arg);

class Test
{
    public static void SMethod(int arg) => WriteLine("Test.SMethod");
    public        void IMethod(int arg) => WriteLine("Test_Object.IMethod");
}

class Program
{
    public static void Main()
    {
        Test t = new Test();

        t.IMethod(1);    // instance method�� ��ü�̸����� ȣ��
        Test.SMethod(1); // static method�� Ŭ���� �̸����� ȣ��
        


        MyFunc f1 = ?;  
        MyFunc f2 = ?;  

        f1(10); 
        f2(10); 


    }
}
