using System;
using static System.Console;

class Program
{
    public static void Main()
    {
        // ? ä�� ������
        ? n = 3;
        ? s = "ABCD";

        ? = Foo;
    }

    public static void Foo(int arg)
    {
        WriteLine($"Foo : {arg}");
    }
}
