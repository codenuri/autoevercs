﻿class CPoint
{
    private int x;
    private int y;
    public CPoint(int a, int b) 
    { 
        x = a; 
        y = b;
    }
}