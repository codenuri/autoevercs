using static System.Console;

// #1. 함수는 기본 적으로 한개의 값을 반환 합니다.
string Get1()
{
    return "john";
}

string ret1 = Get1();

