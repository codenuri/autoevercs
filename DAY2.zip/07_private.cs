﻿using static System.Console;

// 접근 지정자
class Bike
{
    int gear = 0;
}

class Program
{
    public static void Main()
    {
        Bike b = new Bike();
    }
}


