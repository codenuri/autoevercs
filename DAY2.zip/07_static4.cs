﻿using static System.Console;

// 프로그램에서 날짜 를 많이 사용한다.
// => "Date" 라는 타입을 설계 하자


class Program
{
    public static void Main()
    {
    }
}