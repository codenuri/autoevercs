﻿// object 이야기

class Car
{
}

class Program
{
    public static void Main()
    {
        Car c = new Car();
    }
}