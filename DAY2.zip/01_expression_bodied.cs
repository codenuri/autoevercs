int add1(int a, int b)
{
    return a + b;
}

Console.WriteLine( add1(3, 4) );   
