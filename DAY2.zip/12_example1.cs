﻿using static System.Console;

// 파워 포인트 같은 프로그램을 객체지향 프로그램으로 설계해 봅시다.


class Program
{
    public static void Main()
    {

    }
}