﻿string s = null;
int?   n = null;

// null 인지 조사하는 방법 
if ( s == null ) {}
if ( n == null ) {}

if ( s is null ) {}
if ( n is null ) {}
