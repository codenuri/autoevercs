﻿// global.cs
// => 이소스 "컴파일에 포함" 되어야 합니다.
global using System;
global using static System.Console;
