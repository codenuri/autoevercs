// using_visual_sudio.cs

// #1. visual studio 에서 프로젝트 만들기
// 1. "시작버튼" 누르고 "visual studio" 검색후 2022 버전실행
// 2. 새 프로젝트 만들기 선택
// 3. 콘솔앱(.Net) 프로젝트 선택
// 4. 프로젝트 이름(강의에서는 DAY1 이름)
// 5. .net 8.0 화면은 모두 디폴트 선택

// #2. 빌드/실행
// C# 소스 확장자 : .cs
// 빌드 하는 법 : 빌드 메뉴에서 선택하거나
//                "Ctrl + F5" 단축키 => 빌드 후 실행까지

// 폰트등을 변경하려면 "도구- 옵션" 메뉴에서
// => "환경" 하위 메뉴에서 폰트변경 할수 있습니다.
// => "consolas" 가 유명한 개발자용 무료 폰트(MS 제공)

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
