﻿string s = null;
int?   n = null;

// null 인지 조사하는 방법 
if ( s == null ) {}
if ( n == null ) {}

// is 연산자.. 상속 배운후..자세히 
if ( s is null ) {}
if ( n is null ) {}
