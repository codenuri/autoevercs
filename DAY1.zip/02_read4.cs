using System;

// 핵심 : 입력 버퍼가 아닌 키보드로 부터 직접 입력 받기

Console.Write("press any key >> ");


int n = Console.Read();	

