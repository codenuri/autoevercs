using static System.Console;

// casting
double d = 3.4;
int n1 = d;		// ?


// nameof
int color = 100;
string s = "abcd";
string name = nameof(color);

WriteLine($"{nameof(color)} : {color}");				

				

