System.Console.Write("Hello, ");
System.Console.WriteLine("C#");

