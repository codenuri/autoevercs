using static System.Console;

// �ٽ� : while loop

int cnt = 0;

