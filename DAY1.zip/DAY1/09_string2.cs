using System;
using static System.Console;

// �ٽ� #1. 
DateTime tm = new DateTime(2030, 1, 1, 9, 30, 10); // 2030-1-1 9:30:10


// �ٽ� #2.
int    n1 = new int();
string s1 = new string("ABCD")

// �ٽ� #3. 
int    n2 = 0;
string s2 = "ABCD";
