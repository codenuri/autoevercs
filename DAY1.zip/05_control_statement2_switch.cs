using System;

// �ٽ� : switch ��

int num = 1;



object obj = 3.4;


